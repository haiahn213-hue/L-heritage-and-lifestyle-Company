LÁ CONTEMPORARY DESIGN — WEBSITE + TRANG QUẢN TRỊ

CÓ GÌ TRONG BỘ NÀY
- index.html: website catalogue, giỏ hàng mô phỏng, song ngữ Anh–Việt.
- data/products.json: dữ liệu 6 sản phẩm; website đọc dữ liệu này khi chạy trên hosting.
- admin/: giao diện Decap CMS để sửa tên, giá, mô tả và tải ảnh riêng cho từng sản phẩm.
- assets/uploads/: nơi CMS lưu ảnh tải lên.
- HUONG_DAN_CAI_DAT_VI.txt: hướng dẫn cài đặt lần đầu.

LƯU Ý
Bộ tệp này chưa được xuất bản lên mạng và chưa được liên kết với tài khoản GitHub/Netlify của bạn. Trang quản trị chỉ lưu thay đổi online sau khi hoàn tất kết nối GitHub + Netlify và xác thực. Không chia sẻ mật khẩu hoặc GitHub token với người khác.
