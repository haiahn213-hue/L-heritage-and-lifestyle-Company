LÁ CONTEMPORARY DESIGN COMPANY — HƯỚNG DẪN ĐĂNG WEBSITE

1) ĐĂNG WEBSITE LÊN NETLIFY
- Giải nén file ZIP này vào máy tính.
- Đăng nhập tài khoản Netlify: https://app.netlify.com/login
- Mở https://app.netlify.com/drop
- Kéo thả thư mục la_netlify_site (thư mục có file index.html) vào vùng tải lên.
- Chờ Netlify hoàn tất. Sao chép URL có đuôi netlify.app để mở/chia sẻ website.
- Nếu muốn giữ quyền quản lý website, hãy đăng nhập trước khi tải lên.

2) CẬP NHẬT WEBSITE SAU NÀY
- Giữ một bản sao thư mục này trên máy.
- Để cập nhật website, chỉnh sửa file index.html bằng trình soạn thảo phù hợp, sau đó mở trang quản lý site trên Netlify > Deploys và kéo thả lại thư mục đã cập nhật vào vùng deploy thủ công.
- Netlify sẽ xuất bản phiên bản mới; URL website thường được giữ nguyên khi cập nhật đúng site hiện tại.

LƯU Ý QUAN TRỌNG
- Đây là website catalogue/demo tĩnh. Giỏ hàng và tổng tiền chỉ mô phỏng phía trình duyệt; chưa có thanh toán, lưu đơn hàng tập trung hoặc trang quản trị sản phẩm trực quan.
- Netlify Drop không tự cung cấp trình chỉnh sửa nội dung trực quan kiểu kéo-thả cho sản phẩm. Muốn chỉnh sửa giá/ảnh/tên sản phẩm mà không sửa code, cần bổ sung CMS hoặc trang quản trị riêng. Không nhập mật khẩu/thông tin thanh toán vào website demo.
